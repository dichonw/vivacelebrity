<!--script language="JavaScript">document.location='r.ad/?r=home'</script-->    


<!--html>
    <head>
    <title>.:Republic Visual:.</title>
    <link href="adv/logo.ico" rel="icon" type="image/x-icon" />
    </head>

    <frameset rows="0,*" frameborder="no" border="0" framespacing="0">
    <frame src="about:blank" name="topFrame" scrolling="No" noresize="noresize" id="topFrame" title="Republic Visual" />
    <frame src="r.ad/home.php" name="mainFrame" id="mainFrame" title="Republic Visual" />
    </frameset>

    <noframes><body></body></noframes>
    </html-->





<html>
<head>
<title>.:Vivacelebrity:.</title>
<script language=javascript>
setTimeout("location.href='web/?menu=home'", 300);
</script>
<style type="text/css">
img{
   position: absolute;
   top: 50%;
   left: 50%;
   width: 450px;
   height: 450px;
   margin-top: -250px; 
   margin-left: -250px; 
}
</style>
</head>
<body bgcolor="#000000">
<img src="web/logo/logo_loading2.png" width="250">
</body>
</html>
      
      
<!--frameset rows="0,*" frameborder="no" border="0" framespacing="0">
    <frame src="about:blank" name="topFrame" scrolling="No" noresize="noresize" id="topFrame" title="topFrame" />
    <frame src="r.ad/index.php" name="mainFrame" id="mainFrame" title="mainFrame" />
    </frameset>

    <noframes><body></body></noframes>
</frameset--> 