<p>Tambah Daftar Satuan</p>


<form method="POST" action="?menu=proses_tambah_satuan">
<div class="form-group">
        <div class="input-group">
          <div class="input-group-prepend">
            <div class="input-group-text"><abbr title="wajib diisi"></abbr> Satuan</div>
          </div>
          <input type="text" name="satuan" class="form-control" value="" placeholder="Satuan" required="required"  />
        </div>
      </div>

<input type="submit" class="btn btn-primary" name="kirim" value="Simpan">
<a href="?menu=satuan" class="btn btn-danger ">
  <span class="icon text-white-50">
  </span>
  <span class="text">Kembali</span>
</a>
</form>
