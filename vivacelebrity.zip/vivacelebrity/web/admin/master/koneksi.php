<?php
$servername = "localhost";
$username = "republ23_viva";
$password = "t&*2OdacukE77";
$db="republ23_viva";

$koneksi = mysqli_connect($servername, $username, $password, $db);

if (!$koneksi) {
  die("Connection failed: " . mysqli_connect_error());
}

?>