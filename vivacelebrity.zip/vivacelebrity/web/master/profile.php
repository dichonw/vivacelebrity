<link href="../script/style.css" rel="stylesheet" type="text/css">
<link href="../../kasir/main/script/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="../../kasir/main/script/css/font/css/fontawesome.min.css" rel="stylesheet" type="text/css">
<div class="container-fluid pl-0 pr-0 ml-0 mr-0">
  <div class="container">
    <div class="row py-4">        
        <div class="col-lg-6 mx-auto"> 
        <h4 class="text-uppercase">Profile</h4>
            <div class="form-group"> 
            <form method="post" action=""> 
            <input name="id_member" type="hidden" value="" /> 
                <label class="text-capitalize">Pengguna</label>
                <div class="input-group">
                <div class="input-group-prepend">
                    <div class="input-group-text"><i class="far fa-user"></i></div>
                    </div> 
                        <input type="text" name="nm_member" class="form-control" value="">
                </div>     
                </div>
            <div class="form-group"> 
                <label class="text-capitalize">Nomer Handphone</label>
                <div class="input-group">
                <div class="input-group-prepend">
                    <div class="input-group-text"><i class="fab fa-whatsapp"></i></div>
                    </div> 
                        <input type="text" name="hp_member" class="form-control" value="">
                </div>     
                </div> 
            <div class="form-group"> 
                <label class="text-capitalize">Password</label>
                <div class="input-group">
                <div class="input-group-prepend">
                    <div class="input-group-text"><i class="fas fa-unlock-alt"></i></div>
                    </div> 
                        <input type="text" name="pass_member" class="form-control" value="">
                </div>     
                </div>  
            <div class="form-group"> 
                <label class="text-capitalize">Alamat</label>
                <div class="input-group">
                <div class="input-group-prepend">
                    <div class="input-group-text"><i class="fas fa-map-marker-alt"></i></div>
                    </div> 
                        <input type="text" name="almt_member" class="form-control" value="">
                </div>     
                </div>  
                <button name="edit_data" class="btn" style="background-color:#DAA520; color:white;" type="submit">UPDATE</button>     
            </form>     
        
        </div>
        </div>
        </div>